CC_ORG="test"
CC_REPOS="tlc-migration"
GH_ORG="tlconsultinggroup"
CODECOMMIT_URL="ssh://git-codecommit.ap-southeast-2.amazonaws.com/v1/repos/tlc-migration"
# Ensure the required environment variables are set
if [ -z "$CC_USERNAME" ] || [ -z "$CC_TOKEN" ] || [ -z "$CC_ORG" ] || [ -z "$CC_REPOS" ] || [ -z "$GH_PAT" ] || [ -z "$GH_ORG" ] ; then
  echo "One or more required environment variables are not set."
  exit 1
fi

export GH_TOKEN="$GH_PAT"

# Extract username from the JSON response
GH_USER=$(gh api user --jq '.login')

# Check if username is empty or null
if [ -z "$GH_USER" ]; then
    echo "Failed to retrieve username."
    exit 1
fi

echo "Username associated with the GITHUB_TOKEN is: $GH_USER"
repo="$CC_REPOS"

#git clone --bare "ssh://$SSH_KEY_ID@git-codecommit.ap-southeast-2.amazonaws.com/v1/repos/$repo.git"

git clone --bare "https://git-codecommit.ap-southeast-2.amazonaws.com/v1/repos/$repo.git"


  # Check if git clone was successful
  if [ $? -eq 0 ]; then
    # Create a new private repository on GitHub
    gh repo create $GH_ORG/$repo --private

    # Check if gh repo create was successful
    if [ $? -eq 0 ]; then
      # Navigate into the repository
      cd "$repo.git" || continue  # Continue to the next iteration if cd fails

      # Push the repository to GitHub
      git push --mirror "https://$GH_USER:$GH_PAT@github.com/$GH_ORG/$repo.git"

      # Check if git push was successful
      if [ $? -ne 0 ]; then
        failed_migrations+="- $repo\n"
      fi

      # Navigate back to the parent directory
      cd ..
    else
      echo "Creating repository $repo on GitHub failed. Skipping push."
      failed_migrations+="- $repo\n"
    fi
  else
    echo "Cloning repository $repo failed. Skipping creation on GitHub."
    failed_migrations+="- $repo\n"
  fi